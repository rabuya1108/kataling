function sendMessage() {
  const input = document.getElementById("messageInput");
  const messages = document.getElementById("messages");
  if (input.value.trim()) {
    const li = document.createElement("li");
    li.textContent = input.value;
    messages.appendChild(li);
    input.value = "";
    messages.scrollTop = messages.scrollHeight;
  }
}
